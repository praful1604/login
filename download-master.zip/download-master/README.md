download Webjar
===============

A WebJar for the download project.

More info: http://webjars.org

Upstream: https://github.com/kevva/download
